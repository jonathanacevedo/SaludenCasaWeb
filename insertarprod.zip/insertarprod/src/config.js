

export const DB_CONFIG = {
	      apiKey: "AIzaSyCVyrimQuJY_IHWPj7zCvO6c8poNQoRcOc",
    authDomain: "insertarprod.firebaseapp.com",
    databaseURL: "https://insertarprod.firebaseio.com",
    projectId: "insertarprod",
    storageBucket: "insertarprod.appspot.com",
    messagingSenderId: "410754920089"

};